package com.fake.mycalculator

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.channels.Channel
import java.lang.NumberFormatException

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val editText1 = findViewById<EditText>(R.id.editTextText)
        val editText2 = findViewById<EditText>(R.id.editTextText2)
        val operatorSpinner = findViewById<Spinner>(R.id.spinnerOperator)
        val calcButton = findViewById<Button>(R.id.button)
        val resultText = findViewById<TextView>(R.id.textView3)

        val operators = arrayOf("+", "-", "*", "/")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, operators)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        operatorSpinner.adapter = adapter

        calcButton.setOnClickListener {
            val num1 = editText1.text.toString().toDoubleOrNull()
            val num2 = editText2.text.toString().toDoubleOrNull()
            val operator = operatorSpinner.selectedItem.toString()

            if (num1 != null && num2 != null)
            {
                val result = when(operator){
                    "+" -> num1 +  num2
                    "-" -> num1 - num2
                    "*" -> num1 * num2
                    "/" -> if(num2 != 0.0) num1 / num2 else Double.NaN
                    else -> Double.NaN
                }

                resultText.text = "Result: $result"

            }
        }


    }
   /* private fun createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val name = "Calculator Notifications"
            val DescriptionText = "Notifications for calculator results"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val Channel = NotificationChannel(Channel_ID, name, importance).apply {
                description = DescriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(Channel)
        }
    }

    private fun sendNotification(result: Double){
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivities(this, 0, Intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(this, Channel_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground) // use app icon
            .setContentTitle("Calculation completed")
            .setContentText("The result of your calculation is: ${Result}")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(this)){
            notify(1, builder.build())
        }
    }*/
}